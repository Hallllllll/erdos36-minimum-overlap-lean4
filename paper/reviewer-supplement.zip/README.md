# Minimum-overlap proof and measurements

Build with the pinned Lean and Mathlib versions. Run these commands in this directory.

    lake exe cache get
    lake build
    for m in Tree Data Numerical Algebra AffineBridge Profile Spec Main; do
      lake env leanchecker "Overlap.$m" || exit 1
    done
    python3 verify.py
    python3 audit_verify.py
    python3 scripts/check_digit_guards.py
    lake env lean scripts/paper_axioms.lean
    python3 paper/metrics.py --check

The principal declarations are in Overlap/Main.lean. The finite product is checked
in Overlap/Numerical.lean and decoded in Overlap/Algebra.lean. WhiteBridge is an
explicit premise in the discrete-limit result. The supplied measurements and
their commands are described in docs/benchmarks.md. Run bash paper/build.sh
with TeX Live and latexmk to reproduce the manuscript from its included sources.
See paper/REPRODUCE.md for details.
